#pragma once;

namespace another {
	void print();
}