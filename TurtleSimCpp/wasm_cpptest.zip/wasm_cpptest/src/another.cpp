#include <stdio.h>

namespace another {
	void print() {
		printf("Print from another!\n");
	}
}