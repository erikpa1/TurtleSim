

#include <stdio.h>

#include "src/another.h"

int main() {
	printf("Hello, world!\n");
	another::print();
	return 0;
}